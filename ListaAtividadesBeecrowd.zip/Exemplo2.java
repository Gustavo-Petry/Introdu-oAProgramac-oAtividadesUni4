public class Exemplo2 {

    public static void main(String[] args) {

        int idade = 5;

        // priemira verificação
        if (idade >= 18) {
            System.out.println("Esta pessoa é adulta!");
        }

        // segunda verificação
        else if (idade >= 6) {
            System.out.println("Esta pessoa é adolescente!");
        }

        // terceira verificação
        else {
            System.out.println("Esta pessoa é infantil");
        }
    }

}
