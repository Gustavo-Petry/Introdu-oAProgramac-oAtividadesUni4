public class Exemplo3 {

    public static void main(String[] args) {

        int idade = 61;
        if ((idade >= 18) && (idade < 60)) {
            System.out.println("Pagante");
        }
        System.out.println("FIM");

    } 

}
