public class Exemplo1 {

    public static void main(String[] args) {
        
        int idade = 1;

        // priemira verificação
        if (idade >= 18){
            System.out.println("Esta pessoa é adulta!");
        }

        //segunda verificação
        else{
            if(idade >= 12)
            System.out.println("Esta pessoa é adolescente!");
                    
                    //terceira verificação
            else{
                System.out.println("Esta pessoa é infantil");
            }
        }

        




    }

}
